AstroMatch AI v2.3 — Similarity Engine input

Records: 21. Topographic QA-qualified records: 18.
Read features.json["records"]. Each metric is {value, data_status, comparable}.
A pair must match scale, window_km, analysis_resolution_m and method; both values must be non-null and comparable=true.
Use slope_median_deg, slope_p90_deg, flat_fraction, tri_median_m, relief_m, elevation_std_m.
earth_filters (including NDVI/land fraction) are not scoring features. Missing values are null, not zero.
Monthly MODIS overpass temperatures are contextual; their day/night difference is not daily Tmax-minus-Tmin and is not score-ready.
Current approved target: Shackleton. Jezero and Marius Hills remain unapproved until their stated quality gaps are resolved.
Operational QA is not independent absolute accuracy or mission suitability validation.
Global discovery grid is a separate processing/out/pilot delivery. This bundle includes curated Earth sites.
No raw rasters, account credentials, ranking implementation or frontend changes are included.
