AstroMatch AI v2.3 — Similarity Engine input

Records: 21. Topographic QA-qualified records: 18.
Read features.json["records"]. Each metric is {value, data_status, comparable}.
A pair must match scale, window_km, analysis_resolution_m and method; both values must be non-null and comparable=true.
Use slope_median_deg, slope_p90_deg, flat_fraction, tri_median_m, relief_m, elevation_std_m.
Additional data-only descriptors: hypsometric_integral, roughness_ratio, curvature_std_per_km. Existing scores and six-metric QA decisions are unchanged.
Morphology uses measured source samples only (counts > 0 before reprojection for Mars/Moon); quality.morphology records window, support, method and null reasons.
Roughness is median paired population std(3x3)/std(15x15), with at least 6/9 and 150/225 measured samples. Curvature is std of quadratic-fit elevation Laplacian, in km^-1.
Finite morphology values are derived/comparable; undefined ratios or insufficient support remain null/comparable=false. These flags do not promote a record for scoring.
Measured-target subfolders, when present, contain nine interpolated controls and nine sensitivity checks: <=15% relative difference OR absolute HI 0.02, roughness ratio 0.05, curvature 0.01 km^-1. Failed descriptors have comparable=false.
measurement_support.validation_features identifies the legacy six-feature gate; all_nine_sensitivity_passed and nine_feature_validation_passed distinguish nine checks from record approval. Curated QA decisions remain unchanged; Marius measured-only is a separate unpromoted candidate.
earth_filters (including NDVI/land fraction) are not scoring features. Missing values are null, not zero.
Monthly MODIS overpass temperatures are contextual; their day/night difference is not daily Tmax-minus-Tmin and is not score-ready.
Optional annual context uses 2025 monthly MODIS inputs with at least nine accepted months. Context is separate from scoring features; read context_report.md and context_provenance.json when present.
Current approved target: Shackleton. Jezero and Marius Hills remain unapproved until their stated quality gaps are resolved.
Operational QA is not independent absolute accuracy or mission suitability validation.
Discovery uses processing/out/earth_grid.parquet and coverage.geojson. This bundle includes curated Earth sites; its Parquet is not the discovery scan.
No raw rasters, account credentials, ranking implementation or frontend changes are included.
